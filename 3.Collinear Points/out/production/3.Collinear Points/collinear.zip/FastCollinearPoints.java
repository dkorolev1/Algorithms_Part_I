import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class FastCollinearPoints {
    private final List<LineSegment> segments = new ArrayList<>();
    private final List<Point> headers = new ArrayList<>();
    private final List<Double> slopes = new ArrayList<>();

    public FastCollinearPoints(Point[] points)
    {
        if (points == null) {
            throw new IllegalArgumentException("Argument points can't be null.");
        }
        for(int i = 0; i < points.length; i++)
            if (points[i] == null)
                throw new IllegalArgumentException("Array points can't contain null value.");

        for(int i = 0; i < points.length; i++)
            for(int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0) {
                    throw new IllegalArgumentException("Array points can't contain repeated points.");
                }
            }

        for(int i = 0; i < points.length; i++)
        {
            Point p = points[i];
            Point[] restPoints = new Point[points.length - i - 1];
            for(int j = i + 1; j < points.length; j++)
            {
                restPoints[j-i-1] = points[j];
            }
            Arrays.sort(restPoints, p.slopeOrder());

            double slope = 0;
            int pointsCount = 0;
            Point minPoint = p;
            Point maxPoint = p;

            for(int k = 0; k < restPoints.length; k++)
            {
                Point cPoint = restPoints[k];
                if (k == 0) {
                    slope = p.slopeTo(cPoint);
                }
                double currentSlope = p.slopeTo(restPoints[k]);
                if (currentSlope != slope)
                {
                    if (pointsCount >= 3) {
                        tryAddSegment(minPoint, maxPoint, slope);
                    }
                    minPoint = p;
                    maxPoint = p;
                    pointsCount = 1;
                    slope = currentSlope;
                } else {
                    pointsCount ++;
                }

                if (cPoint.compareTo(minPoint) < 0) {
                    minPoint = cPoint;
                }
                if (cPoint.compareTo(maxPoint) > 0) {
                    maxPoint = cPoint;
                }

                if (k == restPoints.length - 1 && pointsCount >= 3) {
                    tryAddSegment(minPoint, maxPoint, slope);
                }
            }
        }
    }

    private void tryAddSegment(Point p, Point q, double slope)
    {
        boolean newSegment = true;
        for (int i = 0; i < headers.size(); i++)
        {
            boolean cond1 = headers.get(i).slopeTo(p) == slopes.get(i) || headers.get(i).slopeTo(p) == Double.NEGATIVE_INFINITY;
            boolean cond2 = headers.get(i).slopeTo(q) == slopes.get(i);

            if (cond1 && cond2) {
                newSegment = false;
            }
        }
        if (newSegment) {
            headers.add(p);
            slopes.add(slope);
            segments.add(new LineSegment(p, q));
        }
    }

    public int numberOfSegments()
    {
        return segments.size();
    }

    public LineSegment[] segments()
    {
        LineSegment[] sArray = new LineSegment[segments.size()];
        return segments.toArray(sArray);
    }
}