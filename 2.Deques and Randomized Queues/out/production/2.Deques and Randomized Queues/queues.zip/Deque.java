import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
    private class Node {
        Item item;
        Node prev;
        Node next;
    }

    private int size;
    private Node head;
    private Node tail;

    public Deque() {
        head = null;
        tail = null;
        size = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    private void addOpeningItem(Item item) {
        Node firstNode = new Node();
        firstNode.item = item;
        head = tail = firstNode;
        size ++;
    }

    // add the item to the front
    public void addFirst(Item item) {
        if (item == null)
        {
            throw new IllegalArgumentException("Argument can't be null");
        }
        if(size == 0) {
            addOpeningItem(item);
        } else {
            Node newNode = new Node();
            newNode.item = item;
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
            size++;
        }
    }

    // add the item to the back
    public void addLast(Item item) {
        if (item == null)
        {
            throw new IllegalArgumentException("Argument can't be null");
        }
        if(size == 0) {
            addOpeningItem(item);
        } else {
            Node newNode = new Node();
            newNode.item = item;
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
            size++;
        }
    }

    // remove and return the item from the front
    public Item removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        Item item = head.item;
        head = head.next;
        if (head != null) {
            head.prev = null;
        }
        size--;
        return item;
    }

    // remove and return the item from the back
    public Item removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        Item item = tail.item;
        tail = tail.prev;
        if (tail != null) {
            tail.next = null;
        }
        size--;
        return item;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return  new ListIterator();
    }

    private class ListIterator implements Iterator<Item>
    {
        private Node current = head;

        public boolean hasNext() {
            return current != null;
        }

        public Item next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            Item item = current.item;
            current = current.next;
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        System.out.println("permutation:" + StdRandom.permutation(5));

        Deque<Integer> d = new Deque<Integer>();
        System.out.println("empty:" + d.isEmpty());

        d.addFirst(1);
        d.addFirst(2);
        d.addFirst(3);
        d.addLast(5);
        d.addLast(6);
        d.addFirst(0);

        d.removeFirst();
        d.removeFirst();
        d.removeLast();

        System.out.println("size:" + d.size());
        System.out.println("empty:" + d.isEmpty());

        Iterator<Integer> iterator = d.iterator();
        while (iterator.hasNext())
        {
            System.out.println(iterator.next());
        }
    }
}